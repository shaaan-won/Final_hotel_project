<?php 
class RoleController{


 function index(){
    view("system");
 }


}




?>