<?php
	use App\Http\Controllers\RoleController;

	Route::resource("roles",[RoleController::class]);
