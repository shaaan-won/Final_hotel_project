<?php 
 echo "this is search page";
?>