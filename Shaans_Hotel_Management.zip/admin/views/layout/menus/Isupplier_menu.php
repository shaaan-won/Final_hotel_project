<li class="nav-item">
				<a class="nav-link" href="<?php echo $base_url ?>supplier">
					<span class="nav-icon">
						<iconify-icon icon="solar:gift-broken"></iconify-icon>
					</span>
					<span class="nav-text"> Supplier </span>
					<!-- <span class="badge bg-danger badge-pill text-end">Hot</span> -->
				</a>
			</li>