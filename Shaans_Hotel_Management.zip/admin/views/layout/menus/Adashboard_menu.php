<li class="nav-item">
	<a class="nav-link" href="<?php echo $base_url ?>home" target="_self">
		<span class="nav-icon">
			<iconify-icon icon="solar:home-2-broken"></iconify-icon>
		</span>
		<span class="nav-text"> Dashboard </span>
		<span class="badge bg-success badge-pill text-end">*</span>
	</a>
</li>