<li class="nav-item">
	<a class="nav-link menu-arrow" href="#sidebarAuthentication" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarAuthentication">
		<span class="nav-icon">
			<iconify-icon icon="solar:lock-password-unlocked-broken"></iconify-icon>
		</span>
		<span class="nav-text"> Authentication </span>
	</a>
	<div class="collapse" id="sidebarAuthentication">
		<ul class="nav sub-navbar-nav">
			<li class="sub-nav-item">
				<a class="sub-nav-link" href="<?php echo $base_url ?>user">Users</a>
			</li>
			<li class="sub-nav-item">
				<a class="sub-nav-link" href="<?php echo $base_url ?>role">Roles List</a>
			</li>

		</ul>
	</div>
</li>