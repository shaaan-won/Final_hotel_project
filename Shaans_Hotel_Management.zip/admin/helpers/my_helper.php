<?php
function myFunction(){
    echo "Hello this is my function";
}



?>